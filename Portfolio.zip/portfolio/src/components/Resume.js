import ResumeImg from '../assets/resume.jpg'

export default function Resume(){
    const config={
        link:'https://drive.google.com/file/d/1TM0x8TXLnWWPzjPkZ9lk2k9ES0wNjCaj/view?usp=drivesdk'
    }
    return (
        <section id="resume" className="flex flex-col md:flex-row bg-blue-900 px-5">
          <div className="w-full flex flex-col lg:flex-row justify-end items-center lg:mt-10 p-5">
            <div className="w-full lg:w-1/3 flex justify-center items-center mb-5 lg:mb-0">
              <img src={ResumeImg} alt="Resume" className="w-full lg:w-[300px] responsive-img" />
            </div>
            <div className="w-full lg:w-1/2 flex flex-col items-center lg:items-start text-white ml-5">
              <h1 className="text-2xl lg:text-4xl text-white border-b-4 border-[#4e4eba] mb-5 font-bold text-center lg:text-left">
                Resume
              </h1>
              <p className="pb-5 text-center lg:text-left">
                You can view my Resume
              </p>
              <a className="btn bg-blue-500 text-white py-2 px-4 rounded mt-2" href={config.link}>
                Download
              </a>
            </div>
          </div>
        </section>
      );
}  
//     return <section id='resume' className='flex flex-col md:flex-row bg-blue-900 px-5'>
       
//     <div className="w-full flex flex-col lg:flex-row justify-end items-center lg:mt-10 p-5">
//         <div className="w-full lg:w-1/3 flex justify-center items-center mb-5 lg:mb-0">
//             <img src={ResumeImg} alt="Resume" className=" w-[300px] responsive-img" />
//         </div>
//         <div className='md:w-1/2 flex justify-center'>
//             <div className="flex flex-col justify-center text-white">
//                 <h1 className=" text-4xl text-white border-b-4 border-[#4e4eba] mb-5 w-[140px] font-bold">Resume</h1>
//                 <p className="pb-5 text-center lg:text-left">You can view my Resume   <a className="btn" href={config.link}>Download</a></p>
//             </div>
//         </div>
//     </div>
// </section>
// }
 

// export default function Resume(){
//     const config={
//         link:'https://drive.google.com/file/d/1TM0x8TXLnWWPzjPkZ9lk2k9ES0wNjCaj/view?usp=drivesdk'
//     }
//     return <section id='resume' className='flex flex-col md:flex-row bg-blue-900 px-5'>
       
//         <div className="py-5 md:w-1/2 flex justify-end">
//             <img className='w-[300px]' src={ResumeImg} />
//         </div>
//         <div className='md:w-1/2 flex justify-center'>
//             <div className="flex flex-col justify-center text-white">
//                 <h1 className=" text-4xl text-white border-b-4 border-[#4e4eba] mb-5 w-[140px] font-bold">Resume</h1>
//                 <p className="pb-5">You can view my Resume   <a className="btn" href={config.link}>Download</a></p>
//             </div>
//         </div>
// </section>

