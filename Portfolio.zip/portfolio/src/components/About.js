import AboutImg from '../assets/about.jpg'

export default function About(){
  const config={
    line1: 'Hi, My name is Leelavathi N V. Im a full-stack developer with a passion for creating dynamic and responsive web applications.',
    line2: 'My expertise includes Java, Python, HTML, CSS, JavaScript, React, Tailwind CSS, SQL.',
    line3: 'Engaged in an internship program to develop my skills and gain hands-on experience to build projects using Frontend and Back-end technologies.',
    line4: 'My goal is to continue growing as a developer and contribute to innovative projects that make a positive impact.'
  }
    return <section className='flex flex-col md:flex-row bg-blue-900 px-5' id='about'>
       
    <div className="w-full flex flex-col lg:flex-row justify-center items-center lg:mt-10 p-5">
        <div className="w-full lg:w-1/3 flex justify-center items-center mb-5 lg:mb-0">
            <img src={AboutImg} alt="About" className="responsive-img" />
        </div>
        <div className="w-full lg:w-2/3 flex flex-col items-center lg:items-start text-white lg:ml-5">
            <h1 className=" text-2xl lg:text-4xl text-white border-b-4 border-[#4e4eba] mb-5 font-bold text-center lg:text-left">About Me</h1>
            <p className="pb-5 text-center lg:text-left">{config.line1}</p>
            <p className="pb-5 text-center lg:text-left">{config.line2}</p>
            <p className="pb-5 text-center lg:text-left">{config.line3}</p>
            <p className="pb-5 text-center lg:text-left">{config.line4}</p>
         </div>
    </div>
    
       {/* <div className='py-5 md:w-1/2'> //normal
            <img src={AboutImg}/>
        </div> */}
      {/* <div className="w-full flex justify-center mt-10">
      <div className="w-1/2 flex flex-col items-center text-white">//normal
    <h1 className="text-4xl text-white border-b-4 border-[#4e4eba] mb-5 w-full text-center font-bold">About Me</h1>
    <p className="pb-5 text-center">Hi, My name is Leelavathi N V. I'm a full-stack developer with a passion for creating dynamic and responsive web applications.</p>
    <p className="pb-5 text-center">My expertise includes Java, Python, HTML, CSS, JavaScript, React, Tailwind CSS, SQL.</p>
    <p className="pb-5 text-center">Engaged in an internship program to develop my skills and gain hands-on experience to build projects using Frontend and Back-end technologies.</p>
    <p className="pb-5 text-center">My goal is to continue growing as a developer and contribute to innovative projects that make a positive impact.</p>
  </div>
</div> */}

    </section>
}
 