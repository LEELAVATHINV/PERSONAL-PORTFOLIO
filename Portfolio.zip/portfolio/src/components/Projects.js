import websiteImg1 from '../assets/startupproject.jpg';
import websiteImg2 from '../assets/diceproject.jpg';
import websiteImg3 from '../assets/registrationform.jpg';

export default function Projects(){
    const config={
        projects: [
            {
                image: websiteImg1,
                description: 'The registration form designed to be user-friendly,secure and ensures that only valid data is entered.',
                link: 'https://github.com/LEELAVATHINV/Startup_Clone_Project'
            },
            {
                image: websiteImg2,
                description: 'The Dice Game is an interactive project where two players compete by rolling dice.',
                link: 'https://github.com/LEELAVATHINV/LEELAVATHINV-Dice-Project'
            },
            {
                image: websiteImg3,
                description: 'The registration form that built with React and Mongodb.',
                link: 'https://github.com/LEELAVATHINV/Registration-Form'
            }
        ]

    }
    return<section id='projects' className="flex flex-col py-20 px-5 justify-center bg-secondary ">
        <div className="w-full">
            <div className="flex flex-col px-10 py-5">
                <h1 className="text-4xl text-white border-b-4 border-[#2d2dba] mb-5 w-[140px] font-bold">Projects</h1>
                <p className='text-white'>These are some of my projects. I have built these with React and TailwindCSS. Check them out.</p>
            </div>
        </div>
        <div className="w-full">
            <div className="flex flex-col md:flex-row px-10 gap-5">
                {config.projects.map((project) => (
                    <a href={project.link}>
                        <div className='relative'>
                            <img className="h-[200px] w-[500px]" src={project.image}></img>
                            <div className='project-desc'>
                                <p className='text-center px-5 py-5 text-white'>{project.description}</p>
                                <div className='flex justify-center'>
                                    <a className='btn text-white' target='_blank' href={project.link}>View Project</a>
                                </div>
                            </div>
                        </div>
                    </a>
                ))}
            </div>
         </div>
    </section>
}
// {/* <div className='relative'>
//                     <img className="h-[200px] w-[500px]" src={websiteImg2}></img>
//                     <div className='project-desc'>
//                         <p className='text-center px-5 py-5 text-white'></p>
//                     </div>
//                 </div>
               
//                 <div className='relative'>
//                     <img className="h-[200px] w-[500px]" src={websiteImg3}></img>
//                     <div className='project-desc'>
//                         <p className='text-center px-5 py-5 text-white'></p>
//                     </div>
//                 </div> */}