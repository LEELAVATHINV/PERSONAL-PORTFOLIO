export default function Footer(){
    return <div className="py-4 bg-blue-900 text-center text-white">&copy; Leela 2024</div>
}